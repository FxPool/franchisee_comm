while true
      do
          ps -ef | grep "fx_d_user_tm" | grep -v "grep"
          if [ "$?" -eq 1 ]
              then
              ./fx_d_user_tm $1 $2 $3 $4 $5 $6 $7 $8
          fi
          sleep 5
done
